package com.example.project2testing;

public class UserData {
    private String name;
    private String phone;
    private String medicalInfo;
    private String relationship;

    // Default constructor (required for Firebase)
    public UserData() {
    }

    public UserData(String name, String phone, String medicalInfo, String relationship) {
        this.name = name;
        this.phone = phone;
        this.medicalInfo = medicalInfo;
        this.relationship = relationship;
    }

    // Getter methods
    public String getName() {
        return name;
    }

    public String getPhone() {
        return phone;
    }

    public String getMedicalInfo() {
        return medicalInfo;
    }

    public String getRelationship() {
        return relationship;
    }


}
