package com.example.project2testing;
import android.annotation.TargetApi;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class checkContactList extends AppCompatActivity {



    private AutoLinkTextView autoLinkTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.check_contact_list);


        Button btnAddData = findViewById(R.id.btnAddData);

        btnAddData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(checkContactList.this, emergencyContact1.class);

                startActivity(intent);
            }
        });

        autoLinkTextView = findViewById(R.id.autoLinkTextView);


        FirebaseApp.initializeApp(this);

        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference().child("EmergencyContact1");

        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange( DataSnapshot dataSnapshot) {
                StringBuilder dataText = new StringBuilder();

                for (DataSnapshot contactSnapshot : dataSnapshot.getChildren()) {
                    String name = contactSnapshot.child("Name").getValue(String.class);
                    String phone = contactSnapshot.child("Phone").getValue(String.class);
                    String relationship = contactSnapshot.child("Relationship").getValue(String.class);
                    String medicalInfo = contactSnapshot.child("MedicalInfo").getValue(String.class);

                    dataText.append("Name: ").append(name).append("\n");
                    dataText.append("Phone: ").append(phone).append("\n");
                    dataText.append("Relationship: ").append(relationship).append("\n");
                    dataText.append("Medical Info: ").append(medicalInfo).append("\n\n");
                }


                autoLinkTextView.setText(dataText.toString());

                autoLinkTextView.setPhoneNumberAutoLinkOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        String phoneNumber = autoLinkTextView.getClickedPhoneNumber();
                        phoneNumber = phoneNumber.replaceAll("[^0-9]", "");

                        if (!phoneNumber.isEmpty()) {

                            Intent intent = new Intent(Intent.ACTION_DIAL);
                            intent.setData(Uri.parse("tel:" + phoneNumber));
                            startActivity(intent);
                        }
                    }
                });


                Button btnClear = findViewById(R.id.btnClear);

                btnClear.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        clearHistory();

                    }
                });


            }

            @Override
            public void onCancelled( DatabaseError databaseError) {

            }

        });
    }
     //need to edit to merge with main branch
    private void clearHistory() {
        DatabaseReference dbRef = FirebaseDatabase.getInstance().getReference().child("EmergencyContact1");
        dbRef.removeValue().addOnCompleteListener(new OnCompleteListener<Void>(){

            @Override
            public void onComplete(Task<Void> task) {
                if(task.isSuccessful()){
                    autoLinkTextView.setText("History Cleared");
                }else{
                    autoLinkTextView.setText("Unsuccessful clear data");
                }
            }
        });
    }
}
