package com.example.project2testing;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class emergencyContact1 extends AppCompatActivity {

    private EditText edName;
    private EditText edRelationship;
    private EditText edPhoneNumber;
    private EditText editTextTextMultiLine;

    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.emergency_contact1);

        // Initialize Firebase with the updated Realtime Database URL
        FirebaseDatabase.getInstance("https://emergencycontact-d344a-default-rtdb.asia-southeast1.firebasedatabase.app/");
        edName = findViewById(R.id.edName);
        edRelationship = findViewById(R.id.edRelationship);
        edPhoneNumber = findViewById(R.id.edPhoneNumber);
        editTextTextMultiLine = findViewById(R.id.editTextTextMultiLine);

        Button btSave = findViewById(R.id.btSave);
        Button btClear = findViewById(R.id.btClear);

        btSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            String name = edName.getText().toString();
            String phone = edPhoneNumber.getText().toString();
            String relationship = edRelationship.getText().toString();
            String medicalInfo = editTextTextMultiLine.getText().toString();

                if (name.isEmpty()) {
                    Toast.makeText(emergencyContact1.this, "No name entered!", Toast.LENGTH_SHORT).show();
                } else if (phone.isEmpty()) {
                    Toast.makeText(emergencyContact1.this, "No phone number entered!", Toast.LENGTH_SHORT).show();
                } else if (relationship.isEmpty()) {
                    Toast.makeText(emergencyContact1.this, "No relationship entered!", Toast.LENGTH_SHORT).show();
                } else if (medicalInfo.isEmpty()) {
                    Toast.makeText(emergencyContact1.this, "No medical information entered!", Toast.LENGTH_SHORT).show();
                } else {

                    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference().child("EmergencyContact1");
                    DatabaseReference newContactReference = databaseReference.push();

                    newContactReference.child("Name").setValue(name);
                    newContactReference.child("Phone").setValue(phone);
                    newContactReference.child("Relationship").setValue(relationship);
                    newContactReference.child("MedicalInfo").setValue(medicalInfo);

                    Toast.makeText(emergencyContact1.this, "Data saved to Firebase!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                clearText();
            }
        });

    }

    private void clearText() {

        edName.getText().clear();
        edRelationship.getText().clear();
        edPhoneNumber.getText().clear();
        editTextTextMultiLine.getText().clear();
    }
}
