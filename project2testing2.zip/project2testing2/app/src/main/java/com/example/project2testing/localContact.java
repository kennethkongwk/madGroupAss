package com.example.project2testing;


import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class localContact extends AppCompatActivity {
private EditText editPhNo;
private Button btSave;
private Button btClear;


private static final String PREFS_NAME = "MyPrefs";
private static final String PRIMARY_PHONENUMBER = "phNo";
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.local_contact);

        editPhNo = findViewById(R.id.editPhNo);
        btSave = findViewById(R.id.btSave);

        previewOldNumber();

        btSave.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                String phNo = editPhNo.getText().toString().trim();

                if(!phNo.isEmpty()){
                    
                    savePhNo(phNo);
                    Toast.makeText(localContact.this, "Phone Contact saved", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(localContact.this,"Please fill in phone number. ", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btClear = findViewById(R.id.btClear);
        btClear.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                clearInput();
            }


        });
    }

    private void clearInput() {
        editPhNo.getText().clear();

    }

    private void savePhNo(String phNo) {
        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(PRIMARY_PHONENUMBER, phNo);
        editor.apply();

        if (editor.commit()) {
            Toast.makeText(localContact.this, "Phone Contact saved", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(localContact.this, "Failed to save phone number", Toast.LENGTH_SHORT).show();
        }

    }

    private void previewOldNumber() {
        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String savedPhNo = sharedPreferences.getString(PRIMARY_PHONENUMBER,"");
        editPhNo.setText(savedPhNo);


    }
}
