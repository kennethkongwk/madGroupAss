package com.example.project2testing;

public @interface NonNull {
}
