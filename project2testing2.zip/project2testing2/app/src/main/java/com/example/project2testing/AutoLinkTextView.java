package com.example.project2testing;

import android.content.Context;
import android.text.util.Linkify;
import android.util.AttributeSet;
import android.view.View;

public class AutoLinkTextView extends androidx.appcompat.widget.AppCompatTextView{
    private View.OnClickListener phoneNumberAutoLinkOnClickListener;
    private String clickedPhoneNumber;

    public AutoLinkTextView(Context context) {
        super(context);
        init();
    }

    public AutoLinkTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public AutoLinkTextView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        // Enable phone number detection and make them clickable
        Linkify.addLinks(this, Linkify.PHONE_NUMBERS);
    }

    public void setPhoneNumberAutoLinkOnClickListener(View.OnClickListener listener) {
        this.phoneNumberAutoLinkOnClickListener = listener;
    }

    public String getClickedPhoneNumber() {
        return clickedPhoneNumber;
    }

    @Override
    public boolean performClick() {
        if (phoneNumberAutoLinkOnClickListener != null) {
            phoneNumberAutoLinkOnClickListener.onClick(this);
            return true;
        }
        return super.performClick();
    }

    @Override
    public void setText(CharSequence text, BufferType type) {
        super.setText(text, type);

        // Extract phone number when a phone link is clicked
        setAutoLinkMask(0); // Remove the default auto-link behavior
        setLinksClickable(true);
        setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (getAutoLinkMask() == 0) {
                    clickedPhoneNumber = getText().toString();
                    performClick();
                }
            }
        });
    }
}
