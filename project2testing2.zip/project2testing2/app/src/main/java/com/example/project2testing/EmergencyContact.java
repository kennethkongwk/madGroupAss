package com.example.project2testing;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;

import android.util.Log;
import android.view.View;
import android.widget.Button;

import android.widget.Toast;


public class EmergencyContact extends AppCompatActivity {

    private static final String PREFS_NAME = "MyPrefs";
    private static final String PRIMARY_PHONENUMBER = "phNo";

    private String phNo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.emergency_contact);

        Button bt1 = findViewById(R.id.bt1);
        Button btnCheck = findViewById(R.id.btnCheck);

        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EmergencyContact.this, emergencyContact1.class);
                startActivity(intent);
            }
        });


        btnCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("EmergencyContact", "btnCheck clicked");
                Intent intent = new Intent(EmergencyContact.this, checkContactList.class);
                startActivity(intent);
            }
        });

        Button btnOffAdd = findViewById(R.id.btnOffAdd);


        btnOffAdd.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EmergencyContact.this, localContact.class);
                startActivity(intent);

            }
        });

        Button btnOffCall = findViewById(R.id.btnOffCall);

        phNo = getSavedPhoneNumber();

        btnOffCall.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                if (!phNo.isEmpty()) {
                    Intent callIntent = new Intent(Intent.ACTION_DIAL);
                    callIntent.setData(Uri.parse("tel:" + phNo));
                    startActivity(callIntent);
                } else {
                    Toast.makeText(EmergencyContact.this, "No phone number stored.", Toast.LENGTH_SHORT).show();
                }
            }
        });


    }

    private String getSavedPhoneNumber() {

            SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            return sharedPreferences.getString(PRIMARY_PHONENUMBER, "");

    }

}
